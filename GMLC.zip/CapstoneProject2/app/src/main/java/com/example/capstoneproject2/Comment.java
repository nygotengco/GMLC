package com.example.capstoneproject2;

public class Comment {

    String comment, uid, time, postkey;

    public Comment() {
    }

    public Comment(String comment, String uid, String time, String postkey) {
        this.comment = comment;
        this.uid = uid;
        this.time = time;
        this.postkey = postkey;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPostkey() {
        return postkey;
    }

    public void setPostkey(String postkey) {
        this.postkey = postkey;
    }
}
