package com.example.capstoneproject2;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;


import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;


import java.util.ArrayList;

public class leaderboards_list extends AppCompatActivity {


    FirebaseFirestore fStore;
    FirebaseDatabase fBase;

    ListView listView;
    ListView dialogListView;

    Button dialogClose;
    TextView dialogText;

    TextView nodata_textView;

    leaderB_adapter LVadapter;
    leaderB_Dialog_adapter LDadapter;

    Dialog leaderbDialog;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboards_list);

        leaderbDialog = new Dialog(this);
        leaderbDialog.setContentView(R.layout.leaderboards_dialog);
        leaderbDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        listView = findViewById(R.id.leaderBListView);
        dialogListView = leaderbDialog.findViewById(R.id.dialog_listView);
        dialogClose = leaderbDialog.findViewById(R.id.dialogClose);
        dialogText = leaderbDialog.findViewById(R.id.dialogText);

        nodata_textView = findViewById(R.id.nodata_textView);

        ArrayList<String> list = new ArrayList<>();

        fBase = FirebaseDatabase.getInstance();
        fStore = FirebaseFirestore.getInstance();

        fStore.collection("Leaderboards").get().addOnSuccessListener(queryDocumentSnapshots -> {
            for (DocumentSnapshot snap:queryDocumentSnapshots.getDocuments()) {
                list.add(snap.getId());
            }
            LVadapter = new leaderB_adapter(leaderboards_list.this, list);

            if(list.size() == 0){
                listView.setVisibility(View.GONE);
                nodata_textView.setVisibility(View.VISIBLE);
            }else{
                listView.setAdapter(LVadapter);
            }

            listView.setOnItemClickListener((parent, view, position, id) -> {
                String subName = parent.getItemAtPosition(position).toString();
                getList(subName);
                dialogText.setText("TOP SCORER FROM "+subName);
                leaderbDialog.show();

            });

        });

        dialogClose.setOnClickListener(v -> leaderbDialog.dismiss());


    }

    private void getList(String subj){

        fStore.collection("Leaderboards").document(subj).collection("scores").orderBy("score", Query.Direction.DESCENDING).get().addOnCompleteListener(task -> {
                ArrayList<String> list = new ArrayList<>();
            for (DocumentSnapshot snap: task.getResult().getDocuments()){
              // values.put(snap.getId(),snap.get("score"));
               list.add(snap.getId()+"-"+snap.get("score"));
               Log.i("MATT", list.toString());
           }

           LDadapter = new leaderB_Dialog_adapter(leaderboards_list.this, list);
           dialogListView.setAdapter(LDadapter);
        });

    }

}