package com.example.capstoneproject2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.util.Patterns;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class Login extends AppCompatActivity {

    ImageView img;
    TextView app_Hello, log_con;
    LottieAnimationView lottieAnimationView;
    TextInputLayout textEmail, textPassword;
    Button f_pass,login_btn, callSignUp, forgotPasswordBtn;
    FirebaseAuth mAuth;
    Dialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //to hide status bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);

        //hooks
        callSignUp = findViewById(R.id.login_signup_button);
        img = findViewById(R.id.logo_image);
        app_Hello = findViewById(R.id.logo_hello);
        log_con = findViewById(R.id.slogan_login);
        textEmail = findViewById(R.id.email);
        textPassword = findViewById(R.id.password);
        f_pass = findViewById(R.id.forgotpass_button);
        login_btn = findViewById(R.id.login_button);
        forgotPasswordBtn = findViewById(R.id.forgotpass_button);

        loadingDialog = new Dialog(Login.this);
        loadingDialog.setContentView(R.layout.loading_progressbar);
        loadingDialog.setCancelable(false);
        loadingDialog.getWindow().setBackgroundDrawableResource(R.drawable.progress_background);
        loadingDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);

        mAuth = FirebaseAuth.getInstance();

        // keep user logged in
        if(mAuth.getCurrentUser() != null){
            startActivity(new Intent(Login.this, ProfilePage.class));
        }

        //redirect to sign up screen
        callSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this,SignUp.class);

                Pair[] pairs = new Pair[7];

                pairs[0] = new Pair<View,String>(img,"logo_image");
                pairs[1] = new Pair<View,String>(app_Hello,"logo_hello");
                pairs[2] = new Pair<View,String>(log_con,"logo_continue");
                pairs[3] = new Pair<View,String>(textEmail,"username_trans");
                pairs[4] = new Pair<View,String>(textPassword,"pass_trans");
                pairs[5] = new Pair<View,String>(f_pass,"fpass_trans");
                pairs[6] = new Pair<View,String>(login_btn,"login_trans");
                startActivity(intent);

                //transition
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(Login.this,pairs);
                    startActivity(intent, options.toBundle());
                }
            }
        });

        //login button with email verification
        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!validateEmail() | !validatePassword()) {
                    return;
                }
                String email = textEmail.getEditText().getText().toString().trim();
                String password = textPassword.getEditText().getText().toString().trim();


                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                            if (user.isEmailVerified()){
                                //redirect to dashboard
                                startActivity(new Intent(Login.this, ProfilePage.class));
                            } else {
                                user.sendEmailVerification();
                                Toast.makeText(Login.this, "Check your email to verify your account", Toast.LENGTH_SHORT).show();
                            }

                        } else {
                            Toast.makeText(Login.this, "Failed to login, Check your credentials", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }

            //form validation for email and password
            private Boolean validateEmail() {
                String val = textEmail.getEditText().getText().toString();

                if (val.isEmpty()) {
                    textEmail.setError("Field Cannot be Empty");
                    textEmail.requestFocus();
                    return false;
                } else {
                    textEmail.setError(null);
                    textEmail.setErrorEnabled(false);
                    return true;
                }
            }

            private Boolean validatePassword() {
                String val = textPassword.getEditText().getText().toString();

                if (val.isEmpty()) {
                    textPassword.setError("Field Cannot be Empty");
                    textPassword.requestFocus();
                    return false;
                } else {
                    textPassword.setError(null);
                    textPassword.setErrorEnabled(false);
                    return true;
                }
            }
        });

        //button to redirect to forgot password page
        forgotPasswordBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadingDialog.show();
                Intent intent = new Intent(Login.this, ForgotPassword.class);
                startActivity(intent);

            }

        });
    }
}