package com.example.capstoneproject2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class Discussion extends AppCompatActivity {

    TextView title, description;
    ImageView postImage, addBtn;

    public static final int PReqCode = 1;
    public static final int REQUESCODE = 1;

    FirebaseAuth mAuth;
    FirebaseUser user;

    ProgressBar clickProgressBar;
    private Uri pickedImgUri  = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discussion);

        postImage = findViewById(R.id.popup_img);
        addBtn = findViewById(R.id.popup_add);

        title = findViewById(R.id.popup_title);
        description = findViewById(R.id.popup_description);

        clickProgressBar = findViewById(R.id.popup_progressBar);

        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();



        //to upload image when clicked
        postImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //check if our app have the access to user files

                checkAndRequestForPermission();

            }
        });


        // Add post click Listener

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                addBtn.setVisibility(View.INVISIBLE);
                clickProgressBar.setVisibility(View.VISIBLE);

                // we need to test all input fields (Title and description ) and post image

                if (!title.getText().toString().isEmpty()
                        && !description.getText().toString().isEmpty()
                        && pickedImgUri != null ) {

                    // TODO Create Post Object and add it to firebase database
                    // first we need to upload post Image
                    // access firebase storage
                    StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("discussion_images");
                    final StorageReference imageFilePath = storageReference.child(pickedImgUri.getLastPathSegment());
                    imageFilePath.putFile(pickedImgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                            imageFilePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    String imageDownloadLink = uri.toString();
                                    // create post Object
                                    Post post = new Post(title.getText().toString(),
                                            description.getText().toString(), imageDownloadLink,
                                            user.getUid());

                                    // Add post to firebase database

                                    addPost(post);



                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    // something goes wrong uploading picture

                                    showMessage(e.getMessage());
                                    clickProgressBar.setVisibility(View.INVISIBLE);
                                    addBtn.setVisibility(View.VISIBLE);



                                }
                            });


                        }
                    });

                }
                else {
                    showMessage("Please verify all input fields and choose an image") ;
                    addBtn.setVisibility(View.VISIBLE);
                    clickProgressBar.setVisibility(View.INVISIBLE);

                }



            }
        });



    }

    private void addPost(Post post) {

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Posts").push();

        // get post unique ID and upadte post key
        String key = myRef.getKey();
        post.setPostKey(key);


        // add post data to firebase database

        myRef.setValue(post).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                showMessage("Post Added successfully");
                clickProgressBar.setVisibility(View.INVISIBLE);
                addBtn.setVisibility(View.VISIBLE);
                Intent intent = new Intent(Discussion.this, DiscussionHome.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void showMessage(String message) {
        Toast.makeText(Discussion.this, message, Toast.LENGTH_LONG).show();
    }

    private void checkAndRequestForPermission() {


        if (ContextCompat.checkSelfPermission(Discussion.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(Discussion.this, Manifest.permission.READ_EXTERNAL_STORAGE)) {

                Toast.makeText(Discussion.this,"Please accept for required permission",Toast.LENGTH_SHORT).show();

            }

            else
            {
                ActivityCompat.requestPermissions(Discussion.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        PReqCode);
            }

        }
        else
            // everything goes well : we have permission to access user gallery
            openGallery();

    }

    private void openGallery() {
        //TODO: open gallery intent and wait for user to pick an image !

        Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,REQUESCODE);
    }

    // when user picked an image
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == REQUESCODE && data != null) {

            // the user has successfully picked an image
            // we need to save its reference to a Uri variable
            pickedImgUri = data.getData();
            postImage.setImageURI(pickedImgUri);

        }
    }

}

