package com.example.capstoneproject2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

public class PostDetailActivity extends AppCompatActivity {

    ImageView imgPost, imgUserPost, imgCurrentUser;
    TextView textPostDesc, textPostDateName, textPostTitle;
    EditText editTextComment;
    Button addCommentBtn;
    String PostKey, visit_UID, current_time, time, postKEY;
    FirebaseAuth mAuth;
    FirebaseUser user;
    FirebaseDatabase database;
    DatabaseReference databaseReference, postRef;
    
    RecyclerView recyclerView;
    CommentAdapter commentAdapter;
    ArrayList<Comment> list;
    static String COMMENT_KEY = "Comment";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_detail);

        imgPost =findViewById(R.id.post_detail_img);
        imgUserPost = findViewById(R.id.post_detail_user_img);
        imgCurrentUser = findViewById(R.id.post_detail_currentuser_img);

        textPostTitle = findViewById(R.id.post_detail_title);
        textPostDesc = findViewById(R.id.post_detail_desc);
        textPostDateName = findViewById(R.id.post_detail_date_name);

        editTextComment = findViewById(R.id.post_detail_comment);
        addCommentBtn = findViewById(R.id.post_detail_add_comment_btn);

        visit_UID = getIntent().getExtras().get("visit_uid").toString();
        postKEY = getIntent().getExtras().get("postKey").toString();

        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();
        database = FirebaseDatabase.getInstance();

        recyclerView = findViewById(R.id.comment_list);
        databaseReference = FirebaseDatabase.getInstance().getReference("Comment");
        postRef = FirebaseDatabase.getInstance().getReference("Posts");
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();

        databaseReference.addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Comment comment = dataSnapshot.getValue(Comment.class);
                    assert comment != null;
                    if(postKEY.equals(comment.getPostkey())) {
                        list.add(comment);
                    }
                    commentAdapter = new CommentAdapter(PostDetailActivity.this, list);
                    commentAdapter.notifyDataSetChanged();
                    recyclerView.setAdapter(commentAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(PostDetailActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        });




        //add comment button
        addCommentBtn.setOnClickListener(view -> {

            Calendar calForTime = Calendar.getInstance();
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                @SuppressLint("SimpleDateFormat") SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm");

                current_time = currentTime.format(calForTime.getTime());
            }

            time = current_time;

            addCommentBtn.setVisibility(View.INVISIBLE);
            DatabaseReference commentReference = database.getReference(COMMENT_KEY).push();
            String comment_content = editTextComment.getText().toString();
            String uid = user.getUid();
            //String uimg = user.getPhotoUrl().toString();
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("comment", comment_content);
            hashMap.put("uid", uid);
            hashMap.put("time", time);
            hashMap.put("postkey", postKEY);

            commentReference.setValue(hashMap).addOnSuccessListener(aVoid -> {
                showMessage("Comment posted successfully");
                editTextComment.setText("");
                addCommentBtn.setVisibility(View.VISIBLE);
            }).addOnFailureListener(e -> showMessage("fail to add comment : "+e.getMessage()));



        });


        String postImage = getIntent().getExtras().getString("postImage") ;
        Glide.with(this).load(postImage).into(imgPost);

        String postTitle = getIntent().getExtras().getString("title");
        textPostTitle.setText(postTitle);

        String userpostImage = getIntent().getExtras().getString("userPhoto");
        Glide.with(this).load(userpostImage).into(imgUserPost);

        String postDescription = getIntent().getExtras().getString("description");
        textPostDesc.setText(postDescription);

        // setcomment user image

        Glide.with(this).load(user.getPhotoUrl()).into(imgCurrentUser);
        // get post id
        PostKey = getIntent().getExtras().getString("postKey");

        String date = timestampToString(getIntent().getExtras().getLong("postDate"));
        textPostDateName.setText(date);

    }


    private void showMessage(String message) {

        Toast.makeText(this,message, Toast.LENGTH_LONG).show();
    }

    private String timestampToString(long time){
        Calendar calendar = Calendar.getInstance(Locale.ENGLISH);
        calendar.setTimeInMillis(time);
        return DateFormat.format("dd-MM-yyyy",calendar).toString();
    }
}