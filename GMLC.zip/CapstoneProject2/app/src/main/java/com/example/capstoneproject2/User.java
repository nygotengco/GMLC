package com.example.capstoneproject2;

public class User {
    public String fname, uname, email;

    public User (){

    }

    public User(String fname, String uname, String email){
        this.fname=fname;
        this.uname=uname;
        this.email=email;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
