package com.example.capstoneproject2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class SignUp extends AppCompatActivity {
    private FirebaseAuth mAuth;

    //variables
    TextInputLayout regFname, regEmail, regUname, regPassword;
    Button regButton, regToLoginButton, callLogin;
    Dialog loadingDialog;

    FirebaseDatabase db = FirebaseDatabase.getInstance();
    DatabaseReference root = db.getReference().child("Users");

    protected void onCreate(Bundle savedInstanceState) {

        mAuth = FirebaseAuth.getInstance();

        super.onCreate(savedInstanceState);
        //to hide status bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_sign_up);

        //elements in activity_sign_up
        regFname = findViewById(R.id.reg_fname);
        regEmail = findViewById(R.id.reg_email);
        regUname = findViewById(R.id.reg_uname);
        regPassword = findViewById(R.id.reg_password);

        regButton = findViewById(R.id.signup_button);
        //regToLoginButton = findViewById(R.id.login_signup_button);
        callLogin = findViewById(R.id.signup_login_button);

        loadingDialog = new Dialog(SignUp.this);
        loadingDialog.setContentView(R.layout.loading_progressbar);
        loadingDialog.setCancelable(false);
        loadingDialog.getWindow().setBackgroundDrawableResource(R.drawable.progress_background);
        loadingDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);


        callLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callLogin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(SignUp.this, Login.class);
                        startActivity(intent);
                    }
                });
            }
        });

        regButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!validateFname() | !validateUname() | !validateEmail() | !validatePassword()) {
                    return;
                }

                String fname = regFname.getEditText().getText().toString().trim();
                String email = regEmail.getEditText().getText().toString().trim();
                String uname = regUname.getEditText().getText().toString().trim();
                String pass = regPassword.getEditText().getText().toString().trim();


                mAuth.createUserWithEmailAndPassword(email, pass)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()){
                                    User user = new User (fname, uname, email);

                                    FirebaseDatabase.getInstance().getReference("Users")
                                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                            .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()){
                                                Toast.makeText(SignUp.this, "User has been registered successfully!", Toast.LENGTH_LONG).show();
                                            } else {
                                                Toast.makeText(SignUp.this, "Failed to register, try again", Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });
                                } else {
                                    Toast.makeText(SignUp.this, "Failed to register", Toast.LENGTH_LONG).show();
                                }
                            }
                        });
            }
        });

    }

    private Boolean validateFname(){
        String val = regFname.getEditText().getText().toString();

        if (val.isEmpty()){
            regFname.setError("Field Cannot be Empty");
            regFname.requestFocus();
            return false;
        }
        else{
            regFname.setError(null);
            regFname.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean validateUname(){
        String val = regUname.getEditText().getText().toString();

        if (val.isEmpty()){
            regUname.setError("Field Cannot be Empty");
            regFname.requestFocus();
            return false;
        }
        else{
            regUname.setError(null);
            regUname.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean validateEmail(){
        String val = regEmail.getEditText().getText().toString();
        String email = "[a-zA-z0-9._-]+@[a-z]+\\.+[a-z]+";

        if (val.isEmpty()){
            regEmail.setError("Field Cannot be Empty");
            regFname.requestFocus();
            return false;
        }
        else if(!val.matches(email)) {
            regEmail.setError("Invalid Email Address");
            regFname.requestFocus();
            return false;
        }
        else{
            regEmail.setError(null);
            return true;
        }
    }

    private Boolean validatePassword(){
        String val = regPassword.getEditText().getText().toString();
        String passwordVal = "^" +
                "(?=.*[a-zA-Z])" + //any letter
                "(?=.*[@#$%^&+=])" + //1 special character
                ".{5,}" + //at least 5 char
                "$";
        if (val.isEmpty()){
            regPassword.setError("Field cannot be empty");
            regFname.requestFocus();
            return false;
        }
        else if (!val.matches(passwordVal)){
            regPassword.setError("Password is too weak. Password must have at least 1 special character and 5 characters");
            return false;
        }
        else {
            regPassword.setError(null);
            return true;
        }
    }
}