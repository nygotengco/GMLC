package com.example.capstoneproject2;

import static com.example.capstoneproject2.IntroActivity.catList;

import androidx.appcompat.app.AppCompatActivity;

import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.GridView;
import androidx.appcompat.widget.Toolbar;

public class CategoryPage extends AppCompatActivity {
    private GridView catGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_page);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Categories");
        toolbar.setTitleTextColor(ContextCompat.getColor(getApplicationContext(), R.color.login_button_bg_color));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        catGrid = findViewById(R.id.cat_recycler);


        CatGridAdapter adapter = new CatGridAdapter(catList);
        catGrid.setAdapter(adapter);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        if (item.getItemId() == android.R.id.home){
            CategoryPage.this.finish();
        }

        return super.onOptionsItemSelected(item);
    }
}