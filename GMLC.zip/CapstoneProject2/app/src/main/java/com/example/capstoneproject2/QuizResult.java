package com.example.capstoneproject2;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class QuizResult extends AppCompatActivity {


    TextView insert_score;
    FirebaseUser fAuth = FirebaseAuth.getInstance().getCurrentUser();
    private DatabaseReference userDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_result);

        insert_score = findViewById(R.id.insert_score);

        userDB = FirebaseDatabase.getInstance().getReference().child("Users");

        String score_str = getIntent().getStringExtra("SCORE");
        String score_val = getIntent().getStringExtra("Score Val");
        String quiz_len = getIntent().getStringExtra("QuestionLen");

        Log.i(TAG, "Categ:" + QuizSet.CategName + "Score:" + score_val);
        int score_int = Integer.parseInt(score_val);
        int quizTotal = Integer.parseInt(quiz_len);

        String id = fAuth.getUid();
        addUserScores(id,QuizSet.CategName,score_int,String.valueOf(QuizSet.setsIDS.get(QuizPage.setNo)), userDB);

        int percentage =  score_int * 100 / quizTotal;

        if(score_int == 0){
            redFlag(id, userDB);
        }
        // if the user have perfect score the Road to Fame will be true
        /*if (quizTotal == score_int){
            roadToFame(id, userDB);
        }*/

        if(quizTotal == 3){
            if (percentage >= 60){
                roadToFame(id, userDB);
            }
        }
        if(quizTotal >= 5){
            if (percentage >= 75){
                roadToFame(id, userDB);
            }
        }




        Log.i(TAG, "Set Number: "+ String.valueOf(QuizSet.setsIDS.get(QuizPage.setNo)));
        Log.i(TAG, "Set ID: "+ String.valueOf(QuizSet.CourseID.toString()));

        Log.i(TAG, "Scores: "+ percentage);
        insert_score.setText(score_str);
    }

    private void addUserScores(String uid, String CategName, int score,String setNo, DatabaseReference userDB){
        userDB.child(uid).child("courses").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //check if the user has already taken the category quiz
                if(snapshot.hasChild(CategName)){
                    userDB.child(uid).child("courses").child(CategName).child("scores").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.hasChild(setNo)){
                                userDB.child(uid).child("courses").child(CategName).child("scores").child(setNo).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<DataSnapshot> task) {
                                        if(!task.isSuccessful()){
                                            Log.e(TAG, "Please check connection between Firebase and App");
                                        }
                                        else{
                                            int currentScore = Integer.parseInt(task.getResult().getValue().toString()); //Current score in DB
                                            int newScore = score; //New Score taken
                                            if (currentScore < newScore){
                                                userDB.child(uid).child("courses").child(CategName).child("scores").child(setNo).setValue(score).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        Toast.makeText(QuizResult.this, "You reach new High Score!", Toast.LENGTH_SHORT).show();
                                                    }
                                                });
                                                totalScore(uid,CategName,userDB);
                                            }else {
                                                if(newScore == 0){
                                                    Toast.makeText(QuizResult.this, "Study More!", Toast.LENGTH_SHORT).show();
                                                }
                                                Toast.makeText(QuizResult.this, "Nice Try!", Toast.LENGTH_SHORT).show();
                                                Log.i(TAG, "Try Again!");
                                            }
                                        }
                                    }
                                });
                            }else{
                                userDB.child(uid).child("courses").child(CategName).child("scores").child(setNo).setValue(score).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(score == 0){
                                            Toast.makeText(QuizResult.this, "Study More!", Toast.LENGTH_SHORT).show();
                                        }else{
                                            Toast.makeText(QuizResult.this, "You reach new High Score!", Toast.LENGTH_SHORT).show();
                                            totalScore(uid,CategName,userDB);
                                        }

                                    }
                                });
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }else{
                    userDB.child(uid).child("courses").child(CategName).child("ID").setValue(QuizSet.CourseID.toString());
                    userDB.child(uid).child("courses").child(CategName).child("scores").child(setNo).setValue(score).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(score == 0){
                                Toast.makeText(QuizResult.this, "Study More!", Toast.LENGTH_SHORT).show();
                            }else{
                                Toast.makeText(QuizResult.this, "You reach new High Score!", Toast.LENGTH_SHORT).show();
                                totalScore(uid,CategName,userDB);
                            }
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




      /*  userDB.child(uid).child("scores").child(CategName).child(setNo).setValue(score).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                Toast.makeText(QuizResult.this, "Score successfully added!", Toast.LENGTH_SHORT).show();
            }
        });
*/

    }

    private void roadToFame(String uid, DatabaseReference userDB){
        userDB.child(uid).get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {
                    if (!dataSnapshot.hasChild("Badges")){
                        dataSnapshot.getRef().child("Badges").child("roadToFame").setValue(true).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful()){
                                            Toast.makeText(QuizResult.this, "You unlocked new Badge!", Toast.LENGTH_SHORT).show();
                                        }
                            }
                        });
                    }
                    else{
                       dataSnapshot.getRef().child("Badges").get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
                           @Override
                           public void onSuccess(DataSnapshot dataSnapshot) {
                                if (!dataSnapshot.hasChild("roadToFame")){
                                    dataSnapshot.getRef().child("roadToFame").setValue(true).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful()){
                                                Toast.makeText(QuizResult.this, "You unlocked new Badge!", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                                }
                           }
                       });
                    }
            }

        });
    }
    private void redFlag(String uid, DatabaseReference userDB){

        userDB.child(uid).get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {
                if (!dataSnapshot.hasChild("Badges")){
                    dataSnapshot.getRef().child("Badges").child("redFlag").setValue(true).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                Toast.makeText(QuizResult.this, "You unlocked new Badge!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
                else{
                    dataSnapshot.getRef().child("Badges").get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
                        @Override
                        public void onSuccess(DataSnapshot dataSnapshot) {
                            if (!dataSnapshot.hasChild("redFlag")){
                                dataSnapshot.getRef().child("redFlag").setValue(true).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful()){
                                            Toast.makeText(QuizResult.this, "You unlocked new Badge!", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                            }
                        }
                    });
                }
            }

        });

    }
    public void callBackQuizCategory(View view) {
        Intent intent = new Intent(QuizResult.this,Dashboard.class);
        startActivity(intent);
    }
    public void totalScore(String uid, String Categname, DatabaseReference childbase){
        FirebaseFirestore fStore = FirebaseFirestore.getInstance();

        childbase.child(uid).get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {
                    String name = dataSnapshot.child("fname").getValue().toString();
                    DatabaseReference newRef = dataSnapshot.getRef().child("courses").child(Categname);
                    newRef.child("scores").get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
                    @Override
                    public void onSuccess(DataSnapshot dataSnapshot) {
                        int totalScore = 0;
                        for (DataSnapshot snap : dataSnapshot.getChildren()) {
                            totalScore += Integer.parseInt(String.valueOf(snap.getValue()));
                        }
                        int finalTotalScore = totalScore;

                        Map<String,Object> nameScore = new HashMap<>();
                        nameScore.put("score",finalTotalScore);

                        Map<String,Object> categVals = new HashMap<>();
                        categVals.put("Last Update", FieldValue.serverTimestamp());

                        fStore.collection("Leaderboards").document(Categname).set(categVals);

                        fStore.collection("Leaderboards").document(Categname).collection("scores").document(name).set(nameScore).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Log.i("TAG", "Firebase Added");
                            }
                        });

                    }
                });

            }
        });


    }
}