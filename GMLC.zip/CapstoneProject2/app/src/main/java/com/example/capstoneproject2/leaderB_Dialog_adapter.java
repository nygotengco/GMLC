package com.example.capstoneproject2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class leaderB_Dialog_adapter extends BaseAdapter {


    Context context;
    ArrayList<String> dialogList;

    public leaderB_Dialog_adapter(Context context, ArrayList<String> dialogList) {
        this.context = context;
        this.dialogList = dialogList;
    }

    @Override
    public int getCount() {
      return dialogList.size();
    }

    @Override
    public Object getItem(int position) {
        return dialogList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.leaderboards_dialog_list, parent,false);
        TextView rank = (TextView) view.findViewById(R.id.leaderB_rankNum);
        TextView name = (TextView) view.findViewById(R.id.leaderB_name);
        TextView score = (TextView) view.findViewById(R.id.leaderB_points);

        String split = dialogList.get(position).toString();
        String[] parts = split.split("-");

        rank.setText("#"+(position + 1) );
        name.setText(parts[0]);
        score.setText(parts[1] + " Points");

        return view;
    }
}
