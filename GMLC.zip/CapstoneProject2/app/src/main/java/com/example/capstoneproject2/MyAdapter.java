package com.example.capstoneproject2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    Context context;
    ArrayList<Post> list;
    FirebaseAuth mAuth;
    FirebaseUser mUser;

    public MyAdapter(Context context, ArrayList<Post> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_post_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Post post = list.get(position);
        holder.tvTitle.setText(post.getTitle());
        Glide.with(context).load(list.get(position).getPicture()).into(holder.imgPost);

    }

    @Override
    public int getItemCount() {

        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView tvTitle;
        ImageView imgPost, imgPostProfile;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTitle = itemView.findViewById(R.id.row_post_title);
            imgPost = itemView.findViewById(R.id.row_post_img);
            imgPostProfile = itemView.findViewById(R.id.row_post_profile_img);
            mAuth = FirebaseAuth.getInstance();
            mUser = mAuth.getCurrentUser();

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent postDetailActivity = new Intent(context,PostDetailActivity.class);
                    int position = getAdapterPosition();

                    postDetailActivity.putExtra("title",list.get(position).getTitle());
                    postDetailActivity.putExtra("postImage",list.get(position).getPicture());
                    postDetailActivity.putExtra("description",list.get(position).getDescription());
                    postDetailActivity.putExtra("postKey",list.get(position).getPostKey());
                    postDetailActivity.putExtra("visit_uid", mUser.getUid());
                    //postDetailActivity.putExtra("userPhoto",list.get(position).getUserPhoto());

                    long timestamp  = (long) list.get(position).getTimeStamp();
                    postDetailActivity.putExtra("postDate",timestamp) ;
                    context.startActivity(postDetailActivity);

                }
            });

        }
    }
}
