package com.example.capstoneproject2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Dashboard extends AppCompatActivity {


    private ImageView callDashboard_profimg, callDashboard_questimg, callDashboard_disscusimg, callDashboard_badgeimg, callDashboard_leaderbimg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //to hide status bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_dashboard);

        callDashboard_profimg = findViewById(R.id.imageViewProfile);
        callDashboard_questimg = findViewById(R.id.imageViewQuest);
        callDashboard_disscusimg = findViewById(R.id.imageViewDiscussion);
        callDashboard_badgeimg = findViewById(R.id.imageViewBadge);
        callDashboard_leaderbimg = findViewById(R.id.imageViewLeaderb);



    }

    public void callDashboard_profileimg(View view) {
        Intent intent = new Intent(Dashboard.this,ProfilePage.class);
        startActivity(intent);
    }

    public void callDashboard_discussimg(View view) {
        Intent intent = new Intent(Dashboard.this,DiscussionHome.class);
        startActivity(intent);
    }

    public void callDashboard_questimg(View view) {
        Intent intent = new Intent(Dashboard.this,CategoryPage.class);
        startActivity(intent);
    }

    public void callDashboard_badgeimg(View view) {
        Intent intent = new Intent(Dashboard.this,Badges.class);
        startActivity(intent);
    }

    public void callDashboard_leaderbimg(View view) {
        Intent intent = new Intent(Dashboard.this,leaderboards_list.class);
        startActivity(intent);
    }


}