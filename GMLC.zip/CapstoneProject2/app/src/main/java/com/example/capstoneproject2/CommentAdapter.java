package com.example.capstoneproject2;

import android.content.Context;
import android.content.Intent;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.CommentViewHolder> {

    Context context;
    ArrayList<Comment> list;
    DatabaseReference user, postRef;
    FirebaseAuth mAuth;
    FirebaseUser mUser;

    public CommentAdapter(Context context, ArrayList<Comment> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_comment, parent, false);
        return new CommentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CommentViewHolder holder, int position) {

        mAuth = FirebaseAuth.getInstance();
        mUser = mAuth.getCurrentUser();
        user = FirebaseDatabase.getInstance().getReference("Users");

        Comment comment = list.get(position);
        holder.tv_content.setText(comment.getComment());
        holder.tv_date.setText(comment.getTime());

        //Glide.with(Context).load(list.get(position).getUimg()).into(holder.img_user);

        user.child(comment.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String u_name = snapshot.child("uname").getValue(String.class);
//                String u_pic = snapshot.child("picture").getValue(String.class);
                holder.tv_name.setText(u_name);
                Glide.with(context).load(R.drawable.userphoto).into(holder.pic);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        //holder.tv_date.setText(timestampToString((Long)list.get(position).getTimestamp()));

    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class CommentViewHolder extends RecyclerView.ViewHolder{

        //ImageView img_user;
        TextView tv_name,tv_content,tv_date;
        ImageView pic;

        public CommentViewHolder(View itemView){
            super(itemView);

            //img_user = itemView.findViewById(R.id.comment_user_img);
            tv_name = itemView.findViewById(R.id.comment_username);
            tv_content = itemView.findViewById(R.id.comment_content);
            tv_date = itemView.findViewById(R.id.comment_date);
            pic = itemView.findViewById(R.id.imageView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent postDetailActivity = new Intent(context,PostDetailActivity.class);
                    int position = getAdapterPosition();

                    postDetailActivity.putExtra("content",list.get(position).getComment());
                    postDetailActivity.putExtra("uid",list.get(position).getUid());


                }
            });
        }
    }

    private String timestampToString(long time) {

        Calendar calendar = Calendar.getInstance(Locale.ENGLISH);
        calendar.setTimeInMillis(time);
        String date = DateFormat.format("hh:mm",calendar).toString();
        return date;


    }

}
