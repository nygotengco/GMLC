package com.example.capstoneproject2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPassword extends AppCompatActivity {

    EditText emailEditText;
    Button resetPassBtn, backBtn;

    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        emailEditText = findViewById(R.id.forgotPassEmailEditText);
        resetPassBtn = findViewById(R.id.resetPassButton);
        backBtn = findViewById(R.id.forgotPassBackButton);

        auth = FirebaseAuth.getInstance();

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ForgotPassword.this, Login.class);
                startActivity(intent);
            }
        });

        resetPassBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!validateEmail()) {
                    return;
                }
                String email = emailEditText.getText().toString().trim();

                auth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(ForgotPassword.this, "Check your email to reset your password", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ForgotPassword.this, "Something went wrong, try again", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }

    private Boolean validateEmail(){
        String val = emailEditText.getText().toString();
        String email = "[a-zA-z0-9._-]+@[a-z]+\\.+[a-z]+";

        if (val.isEmpty()){
            emailEditText.setError("Field Cannot be Empty");
            emailEditText.requestFocus();
            return false;
        }
        else if(!val.matches(email)) {
            emailEditText.setError("Invalid Email Address");
            emailEditText.requestFocus();
            return false;
        }
        else{
            emailEditText.setError(null);
            return true;
        }
    }


}