package com.example.capstoneproject2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class ProfilePage extends AppCompatActivity {

    private Button profileBackBtn, profileLogoutBtn, profileUpdateBtn;
    private TextView profileUname, profileEmailAdd;
    ImageView ImgUserPhoto;
    static int PReqCode = 1;
    static int REQUESCODE = 1;
    Uri pickedImgUri;
    TextInputLayout fullname, username, email, password;
    FirebaseUser user;
    DatabaseReference reference;
    String userID;

    //global variables
    //String _FULLNAME, _USERNAME, _EMAIL, _PASSWORD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);

        reference = FirebaseDatabase.getInstance().getReference("Users");

        profileBackBtn = findViewById(R.id.profile_back_button);
        profileLogoutBtn = findViewById(R.id.logout_btn);
        profileUpdateBtn = findViewById(R.id.update_prof_button);

        fullname = findViewById(R.id.user_prof_fname);
        username = findViewById(R.id.user_prof_uname);
        email = findViewById(R.id.user_prof_email);
        password = findViewById(R.id.user_prof_password);

        ImgUserPhoto = findViewById(R.id.profile_image);

        ImgUserPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT>=22){
                    checkAndRequestForPermission();
                } else {
                    openGallery();
                }
            }
        });

        //show user data
        //showAllUserData();

        profileBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfilePage.this,Dashboard.class);
                startActivity(intent);
            }
        });

        profileLogoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(ProfilePage.this,Login.class));
                Toast.makeText(ProfilePage.this, "Logout successful", Toast.LENGTH_SHORT).show();
            }
        });

        user = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users");
        userID = user.getUid();

        profileUname = findViewById(R.id.user_name);
        profileEmailAdd = findViewById(R.id.user_email);

        reference.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User userProfile = snapshot.getValue(User.class);
                if (userProfile!= null){
                    String uname = userProfile.uname;
                    String email = userProfile.email;

                    profileUname.setText(uname);
                    profileEmailAdd.setText(email);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ProfilePage.this, "Something wrong happened", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openGallery() {

        Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent, REQUESCODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == REQUESCODE && data != null){

            pickedImgUri = data.getData();
            ImgUserPhoto.setImageURI(pickedImgUri);
        }
    }

    private void checkAndRequestForPermission() {
        if (ContextCompat.checkSelfPermission(ProfilePage.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED){
            if (ActivityCompat.shouldShowRequestPermissionRationale(ProfilePage.this, Manifest.permission.READ_EXTERNAL_STORAGE)){
                Toast.makeText(ProfilePage.this, "Please accept for required permission", Toast.LENGTH_SHORT).show();
            }

            else {
                ActivityCompat.requestPermissions(ProfilePage.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        PReqCode );
            }
        }

        else {
            openGallery();
        }

    }

    //update user photo and name
    private void updateUserInfo (String fullname, String username, String email, Uri pickedImgUri, FirebaseUser getCurrentUser){

        StorageReference mStorage = FirebaseStorage.getInstance().getReference().child("users_photos");
        StorageReference imageFilePath = mStorage.child(pickedImgUri.getLastPathSegment());
        imageFilePath.putFile(pickedImgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                //image uploaded successfully
                imageFilePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {

                        UserProfileChangeRequest profileUpdate = new UserProfileChangeRequest.Builder()
                                .setDisplayName(fullname)
                                .setPhotoUri(uri)
                                .build();

                        user.updateProfile(profileUpdate)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()){
                                            //user info updated
                                            Toast.makeText(ProfilePage.this, "Success", Toast.LENGTH_SHORT).show();

                                        }
                                    }
                                });
                    }
                });

            }
        });
    }

    public void update(View view) {
    }
}