package com.example.capstoneproject2;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Badges extends AppCompatActivity {
    TextView master,unstoppable, starter, achiever, gExp, rf, r2f;
    private int courseFinished = 0;
    private long setsFinished = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_badges);

        master = findViewById(R.id.master_badge_description);
        unstoppable = findViewById(R.id.unstoppable_badge_description);
        starter = findViewById(R.id.starter_badge_description);
        achiever = findViewById(R.id.achiever_badge_description);
        gExp = findViewById(R.id.gaining_experience_bagde_description);
        rf = findViewById(R.id.redflag_badge_description);
        r2f = findViewById(R.id.fame_badge_description);

        FirebaseDatabase fbase = FirebaseDatabase.getInstance();
        FirebaseAuth fauth = FirebaseAuth.getInstance();


        String currentUserID = fauth.getCurrentUser().getUid();

        DatabaseReference childBase = fbase.getReference("Users").child(currentUserID).child("courses"); //realtime database

        badgesCourses(fbase,currentUserID,childBase);

        fbase.getReference("Users").child(currentUserID).get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild("Badges")){
                    dataSnapshot.getRef().get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                                if (task.isSuccessful()){
                                    task.getResult().getRef().child("Badges").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                                            if (task.getResult().hasChild("roadToFame")){
                                                boolean roadtoFame = (boolean) task.getResult().child("roadToFame").getValue();
                                                if(roadtoFame == true){
                                                    r2f.setTextColor(Color.parseColor("#00FF00"));
                                                }
                                            }
                                            if(task.getResult().hasChild("redFlag")){
                                                boolean redFlag = (boolean) task.getResult().child("redFlag").getValue();
                                                if(redFlag == true){
                                                    rf.setTextColor(Color.parseColor("#00FF00"));
                                                }
                                            }
                                        }
                                    });

                                }
                        }
                    });
                }
            }
        });

    }

    public void badgesCourses(FirebaseDatabase fbase, String currentUserID, DatabaseReference childBase){

        ArrayList<String> nameOfCourse = new ArrayList<>();
        HashMap<String,String> courseAndID = new HashMap<>();


        fbase.getReference("Users").child(currentUserID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.hasChild("courses")){
                    childBase.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @RequiresApi(api = Build.VERSION_CODES.N)
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            for (DataSnapshot ds:task.getResult().getChildren()) {
                                nameOfCourse.add(ds.getKey());
                                courseAndID.put(ds.getKey(), ds.child("ID").getValue().toString());
                            }
                            checkCourseAndSet(courseAndID, childBase);
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    public void checkCourseAndSet(HashMap<String, String> courseAndSets, DatabaseReference childCount) {
        FirebaseFirestore fStore = FirebaseFirestore.getInstance();
        ArrayList<String> CourseIDs = new ArrayList<>();
        CollectionReference colRef = fStore.collection("QUIZ");
        for (Map.Entry<String, String> entry : courseAndSets.entrySet()) {
            String courseName = entry.getKey();
            String courseID = entry.getValue();
            CourseIDs.add(courseID);
        }
        for (String ids : CourseIDs ) {
            colRef.document(ids).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()){

                        String name = task.getResult().getString("NAME");
                        long setsNumber = task.getResult().getLong("SETS");
                        //Log.i("TAG", "Name:" + name + " Sets Number: " +  setsNumber);

                        childCount.child(name).child("scores").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DataSnapshot> task) {
                                if (task.isSuccessful()){

                                    long count = task.getResult().getChildrenCount();
                                    setsFinished = setsFinished + count;
                                    if(count == setsNumber){
                                        courseFinished++; //Totals Sets of user
                                    }
                                    Log.i("TAG", "Name:" + name + " Sets Number: " +  setsNumber);
                                    Log.i("TAG", "Child Count: " +  count);
                                    numberOfFinishedCourseAndSets(courseFinished, setsFinished);
                                }
                            }
                        });

                    }

                }
            });

        }
        //Log.i("TAG", "Output:" + CourseIDs);

    }
    private void numberOfFinishedCourseAndSets(int courseFinishedValue, long setsFinishedValue){ //(Course Finished, Quiz Sets Finished)
        Log.i("TAG", "Finished Course: " +  courseFinishedValue);
        Log.i("TAG", "Sets Finished Count: " +  setsFinishedValue);
        checkAllCompletedCourse(courseFinishedValue);
        //course finished logic
        if(courseFinishedValue > 0){
            master.setTextColor(Color.parseColor("#00FF00"));
        }
        if(courseFinishedValue >= 3){
            unstoppable.setTextColor(Color.parseColor("#00FF00"));
        }
        //sets finished logic
        if(setsFinishedValue > 0){
            starter.setTextColor(Color.parseColor("#00FF00"));
        }
        if(setsFinishedValue >=3){
            achiever.setTextColor(Color.parseColor("#00FF00"));
        }
    }

    private void checkAllCompletedCourse(int courseFinished){
        FirebaseFirestore fstore =  FirebaseFirestore.getInstance();
        fstore.collection("QUIZ").document("Categories").get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                long numOfAllCourse = documentSnapshot.getLong("COUNT");
                Log.i("TAG","Number of all course: " + numOfAllCourse);

                if (numOfAllCourse == courseFinished){
                    gExp.setTextColor(Color.parseColor("#00FF00"));
                }
            }
        });
    }

}